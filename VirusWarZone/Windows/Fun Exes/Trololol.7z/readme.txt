Once ran you cannot close with Task Manager or Logoff 
(this includes ctrl+atl+del as task manager option vanishes)

alt+f4 will only add more boxes

Press f12 and use the password --> trollface <-- to get rid of it all.